color = 1
