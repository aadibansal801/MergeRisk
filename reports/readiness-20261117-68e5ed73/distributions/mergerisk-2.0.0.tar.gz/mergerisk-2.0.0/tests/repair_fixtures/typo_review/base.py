colour = 1
